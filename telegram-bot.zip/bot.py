import telegram
from telegram.ext import Application, CommandHandler
import jdatetime
from datetime import timedelta, datetime

# توکن ربات
TOKEN = 'YOUR_BOT_TOKEN_HERE'  # توکنت رو اینجا بذار

# تابع برای گرفتن تاریخ شمسی فردا
def get_tomorrow_jalali():
    today = datetime.now()
    tomorrow = today + timedelta(days=1)
    tomorrow_jalali = jdatetime.date.fromgregorian(date=tomorrow)
    return tomorrow_jalali.strftime("%d %B %Y").replace(" ", " ")

# تابع ارسال نظرسنجی
async def send_poll(update, context):
    chat_id = update.message.chat_id
    tomorrow_date = get_tomorrow_jalali()
    
    question = f"نظرسنجی ثبت غذای پرسنلی تاریخ {tomorrow_date}"
    options = ["دریافت فیش ناهار", "دریافت فیش شام"]
    
    await context.bot.send_poll(
        chat_id=chat_id,
        question=question,
        options=options,
        is_anonymous=False,
        allows_multiple_answers=True
    )

# تابع اصلی
def main():
    # ساخت اپلیکیشن بدون پروکسی
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("poll", send_poll))
    application.run_polling()

if __name__ == '__main__':
    main()